#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
set +u; [[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"; set -u
python3 scripts/plot_material_results.py "$@"
