#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
exec "$ROOT/start_material_walk_demo.sh" \
  --cycle 2.20 \
  --step-length 0.075 \
  --clearance 0.060 \
  --forward-speed 0.095 \
  --forward-assist-limit 20 \
  "$@"
