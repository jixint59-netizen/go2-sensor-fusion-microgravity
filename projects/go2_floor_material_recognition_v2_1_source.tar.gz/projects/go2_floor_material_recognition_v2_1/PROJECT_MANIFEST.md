# GO2 Four-Material Floor Recognition V2.1

Core runtime:
- `go2_material_demo/run_demo.py`: MuJoCo simulation and stabilised gait control
- `go2_material_demo/gait.py`: fast four-beat gait with all-feet overlap
- `go2_material_demo/tactile.py`: four foot-contact sensor models and classifier
- `go2_material_demo/dashboard.py`: visible live classification dashboard
- `simulation/mujoco_models/`: GO2 and four-material floor model

Main launchers:
- `start_material_walk_demo.sh`: balanced default mode, dashboard included
- `start_extra_stable_demo.sh`: slower fallback mode
- `start_fast_demo.sh`: faster mode after validation
- `start_stand_sensor_test.sh`: static sensor test
- `show_material_dashboard.sh`: manually open dashboard
- `verify_project.sh`: static and local MuJoCo checks

No gripper, rail, SLAM or map-building code is included.
