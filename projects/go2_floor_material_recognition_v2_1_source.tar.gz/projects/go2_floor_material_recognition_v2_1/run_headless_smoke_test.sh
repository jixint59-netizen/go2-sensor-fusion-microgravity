#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
set +u
[[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"
set -u
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
python3 -m go2_material_demo.run_demo \
  --mode walk \
  --duration 14 \
  --headless \
  --real-time-factor 0 \
  --forward-assist-limit 14 \
  "$@"
