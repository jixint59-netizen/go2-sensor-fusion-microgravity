#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
exec "$ROOT/start_material_walk_demo.sh" \
  --cycle 1.65 \
  --step-length 0.095 \
  --clearance 0.060 \
  --forward-speed 0.145 \
  --forward-assist-limit 22 \
  "$@"
