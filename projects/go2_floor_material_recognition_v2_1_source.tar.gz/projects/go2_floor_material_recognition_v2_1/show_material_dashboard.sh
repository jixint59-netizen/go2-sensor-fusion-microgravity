#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
set +u
[[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"
set -u
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
python3 -m go2_material_demo.dashboard --status-file "$ROOT/data/live_status.json"
