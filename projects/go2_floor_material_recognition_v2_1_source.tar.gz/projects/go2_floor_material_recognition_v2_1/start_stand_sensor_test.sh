#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
set +u; [[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"; set -u
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"; export LIBGL_ALWAYS_SOFTWARE="${LIBGL_ALWAYS_SOFTWARE:-1}"
STATUS_FILE="$ROOT/data/live_status.json"
rm -f "$STATUS_FILE"
python3 -m go2_material_demo.run_demo --mode stand --duration 15 --forward-assist-limit 0 --status-file "$STATUS_FILE" --terminal-rate 2 "$@"
