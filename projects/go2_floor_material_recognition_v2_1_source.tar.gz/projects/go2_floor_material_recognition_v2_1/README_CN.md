# GO2 四材料地板识别 V2.1

## 本次修复

1. 材料识别结果不再依赖 MuJoCo Viewer 内部文字叠加。
2. `start_material_walk_demo.sh` 会自动打开独立的材料识别面板。
3. 终端每秒输出两次四只脚的预测结果，因此即使面板未安装也能看到。
4. 默认速度由约 0.075 m/s 提高到 0.120 m/s。
5. 完整步态周期由 2.80 s 缩短为 1.90 s。
6. 四次摆腿之间增加四脚同时支撑的重叠阶段。
7. 加入关节目标低通、扭矩变化率限制、横向位置稳定、增强姿态稳定和自动恢复模式。
8. 前向辅助不再施加反向制动力。

## 运行

```bash
cd ~/go2_floor_material_recognition_v2_1
./verify_project.sh
./start_material_walk_demo.sh
```

启动后会出现两个窗口：

- MuJoCo 机器人仿真窗口；
- `GO2 Foot Material Recognition` 材料识别面板。

面板中每只脚显示：

- 当前预测材料；
- 仿真真值；
- 置信度；
- 步态阶段；
- 是否接触；
- 法向力；
- 主导触觉频率。

若没有弹出面板：

```bash
sudo apt update
sudo apt install -y python3-tk
```

随后重新运行主脚本。也可以单独启动：

```bash
./show_material_dashboard.sh
```

## 三种速度

默认平衡模式：

```bash
./start_material_walk_demo.sh
```

更稳定：

```bash
./start_extra_stable_demo.sh
```

更快：

```bash
./start_fast_demo.sh
```

首次建议使用默认模式。机器人若进入 `RECOVERY`，控制器会暂停迈腿、恢复站立姿态，再继续行走。

## 结果位置

```text
data/live_status.json
data/logs/material_walk_v2_*.csv
results/
```
