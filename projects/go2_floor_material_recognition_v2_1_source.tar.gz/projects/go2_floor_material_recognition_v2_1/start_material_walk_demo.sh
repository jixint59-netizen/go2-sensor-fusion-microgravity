#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
set +u
[[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"
set -u
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export LIBGL_ALWAYS_SOFTWARE="${LIBGL_ALWAYS_SOFTWARE:-1}"
STATUS_FILE="$ROOT/data/live_status.json"
rm -f "$STATUS_FILE"
DASH_PID=""
cleanup() {
  if [[ -n "$DASH_PID" ]]; then
    kill "$DASH_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT INT TERM
if [[ "${NO_DASHBOARD:-0}" != "1" ]]; then
  if python3 -c 'import tkinter' >/dev/null 2>&1; then
    python3 -m go2_material_demo.dashboard --status-file "$STATUS_FILE" &
    DASH_PID=$!
  else
    echo "NOTE: material dashboard not opened because tkinter is missing."
    echo "Install once with: sudo apt install python3-tk"
    echo "The same results are still printed in this terminal."
  fi
fi
python3 -m go2_material_demo.run_demo \
  --mode walk \
  --duration 45 \
  --camera track \
  --cycle 1.90 \
  --step-length 0.090 \
  --clearance 0.058 \
  --forward-speed 0.120 \
  --forward-assist-limit 18 \
  --status-file "$STATUS_FILE" \
  --terminal-rate 2 \
  "$@"
