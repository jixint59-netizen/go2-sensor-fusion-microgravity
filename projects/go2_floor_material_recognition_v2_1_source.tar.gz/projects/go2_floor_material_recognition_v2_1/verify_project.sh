#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "[1/8] Python syntax"
python3 -m compileall -q go2_material_demo scripts tests

echo "[2/8] Shell syntax"
for f in ./*.sh; do bash -n "$f"; done

echo "[3/8] XML"
python3 -c "import xml.etree.ElementTree as E; E.parse('simulation/mujoco_models/go2_floor.xml'); E.parse('simulation/mujoco_models/scene_four_material_floor.xml'); print('XML OK')"

echo "[4/8] No gripper mechanism"
if grep -RniE 'robotiq|rail_anchor|fingers_actuator' simulation/mujoco_models/*.xml; then
  echo 'ERROR: gripper or rail mechanism remains in model'
  exit 1
fi
echo 'No gripper or rail mechanism in model: OK'

echo "[5/8] IK"
PYTHONPATH="$ROOT:${PYTHONPATH:-}" python3 -c "from go2_material_demo.transforms import two_link_ik; print(two_link_ik(0,-.265)); print('IK OK')"

echo "[6/8] Stable fast gait trajectory"
PYTHONPATH="$ROOT:${PYTHONPATH:-}" python3 tests/test_gait_trajectory.py

echo "[7/8] Visible dashboard interface"
PYTHONPATH="$ROOT:${PYTHONPATH:-}" python3 -m go2_material_demo.dashboard --help >/dev/null
if grep -Rni "add_overlay" go2_material_demo; then
  echo "ERROR: old unsupported viewer overlay remains"
  exit 1
fi
echo "Dashboard/status interface: OK"

echo "[8/8] MuJoCo compile"
set +u
[[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"
set -u
if python3 -c 'import mujoco' >/dev/null 2>&1; then
  python3 -c "import mujoco; m=mujoco.MjModel.from_xml_path('simulation/mujoco_models/scene_four_material_floor.xml'); print(f'MuJoCo OK nq={m.nq} nv={m.nv} nu={m.nu} nsensor={m.nsensor}'); assert m.nu==12"
else
  echo 'SKIP: mujoco unavailable in this shell'
fi

echo "Project verification completed."
