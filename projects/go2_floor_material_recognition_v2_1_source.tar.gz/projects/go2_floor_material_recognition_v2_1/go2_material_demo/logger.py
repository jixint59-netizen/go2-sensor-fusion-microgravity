from __future__ import annotations
import csv,json
class DemoLogger:
    def __init__(self,out,run):
        out.mkdir(parents=True,exist_ok=True); self.csv_path=out/f'{run}.csv'; self.summary_path=out/f'{run}_summary.json'; self.file=self.csv_path.open('w',newline='',encoding='utf-8'); self.writer=None; self.total=0; self.correct=0; self.per={}
    def write(self,row):
        if self.writer is None: self.writer=csv.DictWriter(self.file,fieldnames=list(row)); self.writer.writeheader()
        self.writer.writerow(row); truth=str(row.get('truth','')); pred=str(row.get('prediction',''))
        if truth and pred not in ('','collecting') and row.get('prediction_state')=='READY':
            self.total+=1; self.correct+=int(truth==pred); s=self.per.setdefault(truth,{'total':0,'correct':0}); s['total']+=1; s['correct']+=int(truth==pred)
    def close(self):
        if self.file.closed:return
        self.file.close(); summary={'evaluated_samples':self.total,'correct_samples':self.correct,'overall_accuracy':self.correct/self.total if self.total else None,'per_material':{k:{**v,'accuracy':v['correct']/v['total'] if v['total'] else None} for k,v in self.per.items()},'csv':str(self.csv_path)}; self.summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
