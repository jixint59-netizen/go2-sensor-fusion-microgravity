from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np

from .transforms import smoothstep01, two_link_ik

LEGS = ("FL", "FR", "RL", "RR")


@dataclass(frozen=True)
class GaitParameters:
    """Fast but conservative four-beat gait for the material demo.

    The four swing windows are separated by a short all-feet support interval.
    At most one leg is in swing.  Lift and lowering are vertical, so the foot
    does not scrape horizontally while it is still loaded.
    """

    cycle_s: float = 1.90
    stance_ratio: float = 0.80
    step_length_m: float = 0.090
    clearance_m: float = 0.058
    nominal_foot_z_m: float = -0.270
    ramp_s: float = 2.0
    lift_fraction: float = 0.22
    transfer_fraction: float = 0.56
    lower_fraction: float = 0.22
    probe_amplitude_m: float = 0.0008
    probe_frequency_hz: float = 18.0

    def validate(self) -> None:
        if self.cycle_s <= 0:
            raise ValueError("cycle_s must be positive")
        if not 0.75 <= self.stance_ratio < 0.90:
            raise ValueError("stance_ratio must be in [0.75, 0.90)")
        swing_sum = self.lift_fraction + self.transfer_fraction + self.lower_fraction
        if abs(swing_sum - 1.0) > 1e-9:
            raise ValueError("lift + transfer + lower fractions must equal 1")
        if self.step_length_m < 0 or self.clearance_m <= 0:
            raise ValueError("invalid step length or clearance")


@dataclass(frozen=True)
class FootTarget:
    x_m: float
    z_m: float
    stance: bool
    stage: str
    phase: float


class WaveCrawlGaitController:
    """FL -> RR -> FR -> RL gait with all-feet overlap between swings."""

    def __init__(self, params: GaitParameters | None = None):
        self.p = params or GaitParameters()
        self.p.validate()

        # Phase offsets preserve the requested FL -> RR -> FR -> RL order.
        self.phase_offset = {
            "FL": 0.75,
            "RR": 0.50,
            "FR": 0.25,
            "RL": 0.00,
        }
        self.home = {leg: np.array([0.0, 0.90, -1.80], dtype=float) for leg in LEGS}

    def _swing_target(self, u: float, step: float, clearance: float) -> Tuple[float, float, str]:
        p = self.p
        rear = -0.5 * step
        front = 0.5 * step
        lift_end = p.lift_fraction
        transfer_end = lift_end + p.transfer_fraction

        if u < lift_end:
            v = smoothstep01(u / max(lift_end, 1e-9))
            x = rear
            z = p.nominal_foot_z_m + clearance * v
            stage = "LIFT"
        elif u < transfer_end:
            v = smoothstep01((u - lift_end) / max(p.transfer_fraction, 1e-9))
            x = rear + (front - rear) * v
            z = p.nominal_foot_z_m + clearance
            stage = "TRANSFER"
        else:
            v = smoothstep01((u - transfer_end) / max(p.lower_fraction, 1e-9))
            x = front
            z = p.nominal_foot_z_m + clearance * (1.0 - v)
            stage = "LOWER"
        return x, z, stage

    def desired_foot_targets(self, t_walk: float) -> Dict[str, FootTarget]:
        p = self.p
        ramp = smoothstep01(max(0.0, t_walk) / max(p.ramp_s, 1e-9))
        step = p.step_length_m * ramp
        clearance = p.clearance_m * (0.82 + 0.18 * ramp)

        targets: Dict[str, FootTarget] = {}
        for leg in LEGS:
            phase = (max(0.0, t_walk) / p.cycle_s + self.phase_offset[leg]) % 1.0
            if phase < p.stance_ratio:
                u = phase / p.stance_ratio
                x = 0.5 * step - step * smoothstep01(u)
                gate = math.sin(math.pi * float(np.clip(u, 0.0, 1.0))) ** 2
                probe = (
                    p.probe_amplitude_m
                    * ramp
                    * gate
                    * math.sin(2.0 * math.pi * p.probe_frequency_hz * t_walk)
                )
                z = p.nominal_foot_z_m - probe
                targets[leg] = FootTarget(x, z, True, "STANCE", phase)
            else:
                u = (phase - p.stance_ratio) / (1.0 - p.stance_ratio)
                x, z, stage = self._swing_target(u, step, clearance)
                targets[leg] = FootTarget(x, z, False, stage, phase)
        return targets

    def desired_joints(self, t_walk: float):
        targets = self.desired_foot_targets(t_walk)
        desired = {}
        stance_state = {}
        stage = {}
        for leg, target in targets.items():
            thigh, calf = two_link_ik(target.x_m, target.z_m)
            desired[leg] = np.array([0.0, thigh, calf], dtype=float)
            stance_state[leg] = target.stance
            stage[leg] = target.stage
        return desired, stance_state, stage

    def validate_schedule(self, sample_count: int = 4000) -> None:
        times = np.linspace(0.0, self.p.cycle_s, sample_count, endpoint=False)
        saw_swing = False
        saw_all_stance = False
        for t in times:
            targets = self.desired_foot_targets(float(t + self.p.ramp_s))
            swing_count = sum(not target.stance for target in targets.values())
            if swing_count > 1:
                raise AssertionError(f"more than one swing leg at t={t}: {swing_count}")
            saw_swing |= swing_count == 1
            saw_all_stance |= swing_count == 0
        if not saw_swing:
            raise AssertionError("schedule contains no swing phase")
        if not saw_all_stance:
            raise AssertionError("schedule contains no all-feet support overlap")

        step = self.p.step_length_m
        clearance = self.p.clearance_m
        swing = [
            self._swing_target(float(u), step, clearance)
            for u in np.linspace(0.0, 1.0, 2001)
        ]
        lift_x = [x for x, _, stage in swing if stage == "LIFT"]
        transfer_x = [x for x, _, stage in swing if stage == "TRANSFER"]
        lower_x = [x for x, _, stage in swing if stage == "LOWER"]
        if max(lift_x) - min(lift_x) > 1e-9:
            raise AssertionError("foot moves horizontally during LIFT")
        if max(lower_x) - min(lower_x) > 1e-9:
            raise AssertionError("foot moves horizontally during LOWER")
        if transfer_x[-1] <= transfer_x[0]:
            raise AssertionError("swing transfer is not rear-to-front")
