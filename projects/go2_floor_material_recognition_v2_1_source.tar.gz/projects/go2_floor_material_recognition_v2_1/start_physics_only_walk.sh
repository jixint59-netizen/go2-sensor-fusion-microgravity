#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
set +u
[[ -f "$HOME/ros_mujoco_venv/bin/activate" ]] && source "$HOME/ros_mujoco_venv/bin/activate"
set -u
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export LIBGL_ALWAYS_SOFTWARE="${LIBGL_ALWAYS_SOFTWARE:-1}"
python3 -m go2_material_demo.run_demo \
  --mode walk \
  --duration 80 \
  --cycle 3.20 \
  --step-length 0.080 \
  --clearance 0.075 \
  --forward-assist-limit 0 \
  "$@"
